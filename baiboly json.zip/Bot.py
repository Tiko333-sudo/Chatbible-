import os
import json
import requests
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

# 1. **Telegram Token**
TELEGRAM_TOKEN = "7226367507:AAGcjSu5hEYK6BQzCCSITgQRSL1ETtVjQhw"

# 2. **Hugging Face API Token**
API_TOKEN = "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"

# 3. **Folder misy ny rakitra JSON**
folder_path = "/storage/emulated/0/baiboly-json-master"
baiboly_data = {}

# 4. **Mamaky ny rakitra JSON rehetra ao amin'ny folder**
for file_name in os.listdir(folder_path):
    if file_name.endswith(".json"):  # Mandalo ireo rakitra JSON
        boky = file_name.replace(".json", "")  # Manaisotra ny extension ".json"
        with open(os.path.join(folder_path, file_name), "r", encoding="utf-8") as file:
            baiboly_data[boky] = json.load(file)

# 5. **Function mikaroka tsonga ao amin'ny JSON**
def mahazo_tsonga(verse):
    try:
        boky, toko_andininy = verse.split(" ", 1)
        toko, andininy = toko_andininy.split(":")
        tsonga = baiboly_data[boky][toko][andininy]
        return tsonga
    except KeyError:
        return "Miala tsiny, tsy hita ilay tsonga ao amin'ny rakitra JSON."

# 6. **Function mampiasa Hugging Face API**
def get_response_from_huggingface(input_text):
    API_URL = "https://api-inference.huggingface.co/models/facebook/blenderbot-400M-distill"
    headers = {"Authorization": f"Bearer {API_TOKEN}"}
    payload = {"inputs": input_text}

    # Mandefa fangatahana amin'ny API Hugging Face
    response = requests.post(API_URL, headers=headers, json=payload)
    if response.status_code == 200:
        data = response.json()
        return data.get("generated_text", "Tsy afaka namaly tamim-pahombiazana ny API.")
    else:
        return f"Error: {response.status_code} - {response.text}"

# 7. **Mamaly ny mpampiasa amin'ny Telegram**
def mamaly(update, context):
    user_message = update.message.text

    if ":" in user_message:  # Raha mitady tsonga toy ny "Genesis 1:1"
        tsonga = mahazo_tsonga(user_message)
        final_response = f"Tsonga: {tsonga}"
    else:  # Raha fanontaniana midadasika
        valiny = get_response_from_huggingface(user_message)
        final_response = f"Valiny avy amin'ny API Hugging Face: {valiny}"

    update.message.reply_text(final_response)

# 8. **Hafatra fanombohana**
def manomboka(update, context):
    welcome_message = (
        "Miarahaba! Ity bot dia afaka mitady tsonga ao amin'ny Baiboly sy mamaly fanontaniana lalindalina. Ampidiro tsonga toy ny: 'Genesis 1:1' na lohahevitra toy ny 'What does John 3:16 mean?'."
    )
    update.message.reply_text(welcome_message)

# 9. **Main Function**
def main():
    updater = Updater(TELEGRAM_TOKEN, use_context=True)
    dp = updater.dispatcher

    # Handlers
    dp.add_handler(CommandHandler("start", manomboka))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, mamaly))

    # Alefa ny bot
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()